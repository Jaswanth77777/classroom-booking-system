# Spirit University Classroom Booking System

## Features
- Spirit University image-based login template
- University Email / Student ID / PRN login
- Password with show/hide toggle
- Optional Student / Faculty / Admin role selection
- Automatic role detection when role is left blank
- Remember Me
- Forgot Password flow placeholder
- bcrypt password hashing
- Generic invalid-login error
- Student classroom booking
- Faculty access to see the classroom booking schedule
- Admin access to users and all bookings
- Automatic overlapping-booking conflict detection
- SQLite database
- No OTP and no Twilio

## Run on Windows
1. Open this folder in VS Code.
2. Open Terminal.
3. Run:

```powershell
python -m pip install -r requirements.txt
python app.py
```

4. Open http://127.0.0.1:5000

You can also double-click `run.bat`.

## Demo accounts
Student: `2024BTCY001` / `Student@123`
Faculty: `faculty@spirit.edu` / `Faculty@123`
Admin: `admin@spirit.edu` / `Admin@123`

For a real university deployment, replace the demo users, secret key and development reset flow, and use HTTPS.
